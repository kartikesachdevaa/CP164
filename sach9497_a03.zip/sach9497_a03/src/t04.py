"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-01-27"
-------------------------------------------------------
"""
# Import
from Stack_array import Stack
from utilities import array_to_stack
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


source1 = Stack()
array_to_stack(source1, [3, 6, 1, 7, 9, 14])
print(f"Source Stack: {source1._values}")

source1.reverse()

print(f"Reverse Source Stack: {source1._values}")
