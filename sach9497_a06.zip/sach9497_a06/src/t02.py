"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-02-18"
-------------------------------------------------------
"""
# Imports
from Priority_Queue_linked import Priority_Queue
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


pq = Priority_Queue()

pq.insert('z')
pq.insert('y')
pq.insert('z')

print(pq._front._value, pq._count)
