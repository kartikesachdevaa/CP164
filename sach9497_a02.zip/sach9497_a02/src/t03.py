"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-01-21"
-------------------------------------------------------
"""
# Imports
from Food_utilities import calories_by_origin
from Food import Food
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


food_1 = Food("grape", 3, True, 67)
food_2 = Food("chicken", 2, False, 67)
food_3 = Food("Vegetable Alicha", 3, True, 138)

foods = [food_1, food_2, food_3]

by_origin = calories_by_origin(foods, 3)

print(by_origin)
