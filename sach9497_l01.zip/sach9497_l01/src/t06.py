"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-01-12"
-------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import write_foods
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


a = open("new_foods.txt", "w")

f = Food("Biryani", 2, False, 130)
h = Food("Beaver Tail", 0, True, 500)

m = [f, h]

write_foods(a, m)
