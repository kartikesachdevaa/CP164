"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-03-31"
-------------------------------------------------------
"""
# Imports
from Sorts_array import Sorts

# Constants


a = [13, 1345, 452, 3, 456, 62, 2038]

Sorts.gnome_sort(a)

print(a)
