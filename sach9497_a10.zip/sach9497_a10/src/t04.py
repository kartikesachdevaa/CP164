"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-03-31"
-------------------------------------------------------
"""
# Imports
from Sorts_Deque_linked import Sorts
from Deque_linked import Deque
# Constants


a = Deque()
a.insert_front(23)
a.insert_front(765)
a.insert_front(9)
a.insert_front(3)
a.insert_front(55)
a.insert_front(986)
a.insert_front(24623)


Sorts.gnome_sort(a)

for i in a:
    print(i)
