"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-03-31"
-------------------------------------------------------
"""
# Imports
from Sorts_array import Sorts
# Constants

a = [1, 64, 3, 345, 5, 26, 75, 775, 42567, 286]

Sorts.radix_sort(a)

print(a)
