"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-02-04"
-------------------------------------------------------
"""
# Imports
from Priority_Queue_array import Priority_Queue
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


pq = Priority_Queue()
pq.insert(2)
pq.insert(4)
pq.insert(6)
pq.insert(8)
pq.insert(10)
key = 3

print(pq._values)
target1, target2 = pq.split_key(key)
print(target1._values, target2._values)
