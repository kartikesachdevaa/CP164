"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-03-02"
-------------------------------------------------------
"""
# Imports
from List_linked import List
# Constants


l = List()
l.append(22)
l.append(33)
l.append(11)
l.append(55)
l.append(44)
l.append(None)

l.reverse_r()

print(l._rear._value, l._front._value, l._front._next._value, l._front._next._next._value,
      l._front._next._next._next._value, l._front._next._next._next._next._value, l._front._next._next._next._next._next._value)
