"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-01-13"
-------------------------------------------------------
"""
# Imports
from functions import file_analyze
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


f = "testing_file.txt"
fv = open(f, "r", encoding="utf-8")
upp, low, dig, whi, rem = file_analyze(fv)
print("uppers: ", upp)
print("lowers: ", low)
print("digits: ", dig)
print("whitespace: ", whi)
print("other: ", rem)
