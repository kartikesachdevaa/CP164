"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-01-13"
-------------------------------------------------------
"""
# Imports
from functions import list_subtraction
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


minuend_input = input("Enter the minuend list of values separated by commas: ")
subtrahend_input = input("Enter the subtrahend list of values separated by commas: ")

minuend = [int(x) for x in minuend_input.split(',')]
subtrahend = [int(x) for x in subtrahend_input.split(',')]

list_subtraction(minuend, subtrahend)

print("Minuend after subtraction:", minuend)
