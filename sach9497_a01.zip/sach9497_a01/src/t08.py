"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-01-13"
-------------------------------------------------------
"""
# Imports
from functions import matrix_stats
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


rows = int(input("Enter the number of rows: "))
columns = int(input("Enter the number of columns: "))

user_matrix = []
for i in range(rows):
    row = list(map(float, input(f"Enter values for row {i + 1} separated by spaces: ").split()))
    user_matrix.append(row)

small, large, total, average = matrix_stats(user_matrix)
print("Smallest:", small)
print("Largest:", large)
print("Total:", total)
print("Average:", average)
