"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2024-01-19"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from utilities import array_to_stack
from utilities import stack_to_array
from utilities import stack_test
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


stack = Stack()
source = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

array_to_stack(stack, source)

target = source

stack_to_array(stack, target)

print(target, source)

print(stack._values)


print(stack_test(source))
